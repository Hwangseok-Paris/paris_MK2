import ThemeToggle from "../components/common/ThemeToggle";

export default function Home() {
  return (
    <div>
      <ThemeToggle />
    </div>
  );
}
